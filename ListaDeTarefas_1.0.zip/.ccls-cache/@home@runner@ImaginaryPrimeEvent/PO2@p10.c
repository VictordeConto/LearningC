#include <stdio.h>
void printd(int n){
  printf("%d",n);
}