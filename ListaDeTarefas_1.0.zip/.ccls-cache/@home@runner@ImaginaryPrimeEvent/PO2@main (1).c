#include <stdio.h>
#include <stdlib.h>

struct sxy {
   int x;
   int y;
   struct sxy *next, *prev;
};
typedef struct sxy txy;

struct stag {
   txy *head;
   txy *tail;
};
typedef struct stag ttag;

void init_lista(ttag *t)
{
  t->head=NULL;
  t->tail=NULL;
}
void incluir (ttag *t,int x, int y)
{
  txy *p;
  // passo 1: alocar memória para o novo elemento
  p=(txy *)malloc(sizeof(txy));
  // passo 2: preencher o novo elemento
  p->x=x;
  p->y=y;
  p->prev=NULL;
  p->next=NULL;
  // passo 3: encadear
  if (t->head==NULL)
  {
    t->head=p;
    t->tail=p;
  } else {
    t->tail->next=p;
    p->prev=t->tail;
    t->tail=p;
    
  }
  return;
}

void consultar (ttag t,int x, int y)
{
  if (t.head==NULL)
  {
    return;
    }
    return;
}

void excluir (ttag *t,int x, int y)
{
  if (t->head==NULL)
  {
    printf("Lista vazia!\n");
    return;
  }
  txy *p;
  for (p=t->head;p!=NULL;p=p->next)
  {
      if (p->x==x && p->y==y)
      {
         if (p==t->head) // endereço do primeiro elemento
         {
            t->head=p->next;
            if (t->head==NULL) {
              t->tail=NULL;
              free(p);
              break;
            }
            t->head->prev=NULL;
            free(p);
            break;
         }
         if (p==t->tail)
         {
            t->tail=p->prev;
            t->tail->next=NULL;
            free(p);
            break;
         }
         p->prev->next=p->next;
         p->next->prev=p->prev;
         free(p);
         break;
      }
  }
  if (p==NULL)
  {
    printf("(%d,%d) não encontrado\n",x,y);
  }
  return;
}

void lista_todos(ttag t)
{
  if (t.head==NULL)
  {
     printf("Lista vazia!\n");
     return;
  }
  txy *p;
  for (p=t.head;p!=NULL;p=p->next)
    printf("(%d,%d)\n",p->x,p->y);
  return;
}

int menu()
{
    int op;
    printf("1 - Incluir\n2 - Consultar\n3 - Excluir\n4 - Listar \n0 - Finalizar\n: ");
    scanf("%d",&op);
    return op;
}
//
int main()
{
   ttag tag;
   int op, x,y;
   init_lista(&tag);
   op=menu();
   while (op!=0)
   {
      switch(op)
      {
         case 1: scanf("%d %d",&x,&y);
                 incluir(&tag,x,y);
                 break;
         case 2: scanf("%d %d",&x,&y);
                 consultar(tag,x,y);
                 break;
         case 3: scanf("%d %d",&x,&y);
                 excluir(&tag,x,y);
                 break;
         case 4: lista_todos(tag);
                 break;
      }
      op=menu();
   }
   return 0;
}