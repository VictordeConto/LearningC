                    //----------------------------------------------------------------------------------------
                    // UNIVERSIDADE FEDERAL DA FRONTEIRA SUL - CAMPUS CHAPECÓ
                    // TRABALHO FINAL ESTRUTURA DE DADOS: LISTA DE TAREFAS EM C
                    // PROFESSOR: DENIO DUARTE
                    // ESTUDANTES: VICTOR NEYMAR DE CONTO (20230004269) E RAIEL VITOR BABINSKI (20230003539)
                    //----------------------------------------------------------------------------------------

                    #include <stdio.h>
                    #include <stdlib.h>
                    #include <string.h>
                    #include <ctype.h>

                    typedef struct noLista { // <---- Estrutura que armazena as informações de cada tarefa
                        int id;
                        char tarefa[20];
                        char ativa[20];
                        int tempConclusao;
                        struct noLista *next;
                        struct noLista *prev;
                    } listaTarefa;

                    typedef struct sent {  // <---- Estrutura que armazena cada lista de tarefas
                        listaTarefa *head;
                        listaTarefa *tail;
                    } sentinela;

                    typedef struct MenorValor{
                        int menorTemp;
                    }menorTempo;

                    void iniciMenorTemp(menorTempo *m){
                        m->menorTemp = -1;
                    }

                    void criarLista(sentinela *s) { // <---- Inicializador
                        s->head = NULL;
                        s->tail = NULL;
                    }

                    void inserirElemento(sentinela *s, int sid, char t[], int temp, menorTempo *m) {
                        listaTarefa *aux2, *novo = malloc(sizeof(listaTarefa));
                        if (!novo) {
                            printf("Erro de alocação de memória.\n");
                            return;
                        }

                        aux2 = s->head;

                        while (aux2 != NULL) {
                            if (aux2->id == sid) {
                                printf("ID já existente\n");
                                free(novo);
                                return;
                            }
                            aux2 = aux2->next;
                        }

                        novo->id = sid;
                        strcpy(novo->tarefa, t);
                        strcpy(novo->ativa, "Ativa");
                        novo->tempConclusao = temp;
                        novo->next = NULL;
                        novo->prev = NULL;

                        if (s->head == NULL) {
                            s->head = novo;
                            s->tail = novo;
                            m->menorTemp = novo->tempConclusao;
                        } else {
                            if (novo->tempConclusao < m->menorTemp) {
                                novo->next = s->head;
                                s->head->prev = novo;
                                s->head = novo;
                                m->menorTemp = novo->tempConclusao;
                            } else {
                                s->tail->next = novo;
                                novo->prev = s->tail;
                                s->tail = novo;
                            }
                        }
                    }

                    void concluirTarefa(sentinela *s1, sentinela *s2, int sid, menorTempo *Menor2){
                        listaTarefa *aux = s1->head;

                        while (aux != NULL) {
                            if (aux->id == sid) {
                                strcpy(aux->ativa, "Concluída");

                                // Remove from active list
                                if (aux == s1->head && aux == s1->tail) {
                                    s1->head = NULL;
                                    s1->tail = NULL;
                                } else if (aux == s1->head) {
                                    s1->head = aux->next;
                                    s1->head->prev = NULL;
                                } else if (aux == s1->tail) {
                                    s1->tail = aux->prev;
                                    s1->tail->next = NULL;
                                } else {
                                    aux->prev->next = aux->next;
                                    aux->next->prev = aux->prev;
                                }

                                // Insert into completed list
                                inserirElemento(s2, aux->id, aux->tarefa, aux->tempConclusao, Menor2);

                                free(aux);
                                printf("A tarefa com ID %d foi concluída com sucesso!\n", sid);
                                return;
                            }
                            aux = aux->next;
                        }
                        printf("Tarefa com ID %d não encontrada.\n", sid);
                    }

                    void removeTarefa(sentinela *s, int sid) {
                        listaTarefa *aux = s->head;

                        while (aux != NULL) {
                            if (aux->id == sid) {
                                if (aux == s->head && aux == s->tail) {
                                    s->head = NULL;
                                    s->tail = NULL;
                                } else if (aux == s->head) {
                                    s->head = aux->next;
                                    s->head->prev = NULL;
                                } else if (aux == s->tail) {
                                    s->tail = aux->prev;
                                    s->tail->next = NULL;
                                } else {
                                    aux->prev->next = aux->next;
                                    aux->next->prev = aux->prev;
                                }
                                free(aux);
                                printf("A tarefa com ID %d foi removida com sucesso!\n", sid);
                                return;
                            }
                            aux = aux->next;
                        }
                        printf("Tarefa com ID %d não encontrada.\n", sid);
                    }

                    void imprimiLT(sentinela s) {
                        listaTarefa *aux = s.head;
                        printf("\nLISTA DE TAREFAS\n\n");
                        while (aux) {
                            printf("ID: %d\nDescrição: %s\nSituação: %s\nTempo limite: %d horas\n",
                                   aux->id, aux->tarefa, aux->ativa, aux->tempConclusao);
                            aux = aux->next;
                            printf("---------------------------\n");
                        }
                    }

                    int lerInteiro(int *valor) {   // Função para verificar se é inteiro
                        char buffer[100];
                        char *endptr;
                        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
                            size_t len = strlen(buffer);
                            if (len > 0 && buffer[len - 1] == '\n') {
                                buffer[len - 1] = '\0';
                            }
                            *valor = strtol(buffer, &endptr, 10);
                            if (endptr == buffer || *endptr != '\0') {
                                return 0; 
                            }
                            return 1; 
                        }
                        return 0;
                    }

                    int main() {
                        sentinela listaAtiva;
                        sentinela listaConcluida;
                        menorTempo Menor;
                        menorTempo Menor2;
                        int opcao;
                        int idTarefa;
                        char nomeTarefa[20];
                        int tempTarefa;

                        iniciMenorTemp(&Menor);
                        iniciMenorTemp(&Menor2);
                        criarLista(&listaAtiva); // Lista das tarefas que estão ativas
                        criarLista(&listaConcluida); // Lista das tarefas que foram concluídas

                        do {
                            printf("\nMenu de opções:\n\n0- Sair do menu\n1- Adicionar nova tarefa\n2- Concluir tarefa\n3- Excluir tarefa\n4- Visualizar tarefas\n");
                            if (!lerInteiro(&opcao)) {
                                printf("Opção inválida. Por favor, digite um número inteiro.\n");
                                continue;
                            }

                            switch (opcao) {
                                case 1:
                                    printf("Digite um ID para a tarefa:\n");
                                    if (!lerInteiro(&idTarefa)) {
                                        printf("ID inválido. Por favor, digite um número inteiro.\n");
                                        break;
                                    }

                                    printf("Digite a descrição da tarefa:\n");
                                    fgets(nomeTarefa, sizeof(nomeTarefa), stdin);
                                    size_t len = strlen(nomeTarefa);
                                    if (len > 0 && nomeTarefa[len - 1] == '\n') {
                                        nomeTarefa[len - 1] = '\0';
                                    }

                                    printf("Digite o tempo para conclusão da tarefa:\n");
                                    if (!lerInteiro(&tempTarefa)) {
                                        printf("Tempo para conclusão inválido. Por favor, digite um número inteiro.\n");
                                        break;
                                    }

                                    inserirElemento(&listaAtiva, idTarefa, nomeTarefa, tempTarefa, &Menor);
                                    printf("A tarefa %s foi adicionada com sucesso!\n", nomeTarefa);
                                    break;
                                case 2:
                                    printf("Digite o ID da tarefa a ser concluída:\n");
                                    if (!lerInteiro(&idTarefa)) {
                                        printf("ID inválido. Por favor, digite um número inteiro.\n");
                                        break;
                                    }
                                    concluirTarefa(&listaAtiva, &listaConcluida, idTarefa, &Menor2);
                                    break;
                                case 3:
                                    printf("Digite o ID da tarefa a ser removida:\n");
                                    if (!lerInteiro(&idTarefa)) {
                                        printf("ID inválido. Por favor, digite um número inteiro.\n");
                                        break;
                                    }
                                    removeTarefa(&listaAtiva, idTarefa);
                                    break;
                                case 4:
                                    printf("\nOpções de visualização:\n\n1- Visualizar tarefas ativas\n2- Visualizar tarefas concluídas\n3- Visualizar todas as tarefas\n0- Voltar ao menu principal\n");
                                    int opcao2;
                                    if (!lerInteiro(&opcao2)){
                                      printf("Opção inválida. Por favor, digite um número inteiro.\n");
                                      break;
                                    }
                                    switch (opcao2) {
                                        case 1:
                                            imprimiLT(listaAtiva);
                                            break;
                                        case 2:
                                            imprimiLT(listaConcluida);
                                            break;
                                        case 3:
                                            printf("\nTAREFAS ATIVAS:\n");
                                            imprimiLT(listaAtiva);
                                            printf("\nTAREFAS CONCLUÍDAS:\n");
                                            imprimiLT(listaConcluida);
                                            break;
                                        case 0:
                                            break;
                                        default:
                                            printf("Opção Inválida\n");
                                    }
                                    break;
                                default:
                                    if (opcao != 0) {
                                        printf("Opção Inválida\n");
                                    }
                            }
                        } while (opcao != 0);

                        return 0;
                    }
