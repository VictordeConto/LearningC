#include <stdio.h>

int main() 
{
  int HorasTrabalhadas;
  printf("Horas trabalhadas: ");
  scanf("%d", &HorasTrabalhadas);

  int valorhora;
  printf("Valor da hora: ");
  scanf("%d", &valorhora);
  
float salario;
  salario = HorasTrabalhadas * valorhora;
  
if (HorasTrabalhadas > 200)
{ salario = salario + (salario * 0.05);
  
}
  printf("Salario: %.2f", salario);
    
  return 0;
}