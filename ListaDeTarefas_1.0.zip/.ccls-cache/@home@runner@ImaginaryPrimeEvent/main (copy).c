#include <stdio.h>
#include <stdlib.h>

typedef struct no{
  int valor;
  struct no *proximo;
  struct no *anterior;
}No;

typedef struct{
  No *inicio;
  No *fim;
  int tam;
}Lista;

void inserir_inicio(Lista *lista, int num);
Lista division(Lista *l1, Lista *l2){
  Lista *l3 = (Lista*)malloc(sizeof(Lista));
  l3->inicio = NULL;
  l3->fim = NULL;
  No *aux;
  while(l1->inicio->proximo != NULL || l2->inicio->proximo != NULL){
    if(l1->inicio->valor != l2->inicio->valor){
      inserir_inicio(l3, l2->inicio->valor);
      l2->inicio = l2->inicio->proximo;
      l1->inicio = l1->inicio->proximo;
      
  }
}

void criar_fila(Lista *fila){
fila->inicio = NULL;
fila->fim = NULL;
}

void inserir_fila(Lista *fila, int num){
  No *aux, *novo = malloc(sizeof(No));
  if(novo){
    novo->valor = num;
    novo->proximo = NULL;
    if(fila->inicio == NULL){
      fila->inicio = novo;
      fila->fim = novo;
    }
    else{
      fila->fim->proximo = novo;
      fila->fim = novo;
    }
  }
}

void remover_fila(Lista *fila){
  No *aux = fila->inicio;
  fila->inicio = fila->inicio->proximo;
  free(aux);
}

void imprimir_fila(Lista fila){
  No *aux = fila.inicio;
  while(aux)
    printf("%d ", aux->valor);
    aux = aux->proximo;
}

void criar_pilha(Lista *pilha){
  pilha->inicio = NULL;
}

void inserir_pilha(Lista *pilha, int num){
  No *novo = malloc(sizeof(No));
  if(novo){
    novo->valor = num;
    novo->proximo = pilha->inicio;
    pilha->inicio = novo;
  }
}

void remover_pilha(Lista *pilha){
  No *remover = pilha->inicio;
  pilha->inicio = remover->proximo;
  free(remover);
}

void imprimir_pilha(Lista pilha){
  No *aux = pilha.inicio;
  while(aux){
    printf("\n%d \n", aux->valor);
    aux = aux->proximo;
    printf("\n\n");
  }
}

void criar_lista(Lista *lista){
  lista->inicio = NULL;
  lista->tam = 0;
}

void inserir_inicio(Lista *lista, int num){
  No *novo = malloc(sizeof(No));
  if(novo){
    novo->valor = num;
    novo->proximo = lista->inicio;
    lista->inicio = novo;
    lista->tam++;
  }
  else{
    printf("Erro ao alocar memória\n");
  }
}

void inserir_fim(Lista *lista, int num){
  No *aux, *novo = malloc(sizeof(No));
  if(novo){
    novo->valor = num;
    novo->proximo = NULL;
    if (lista->inicio == NULL){
      lista->inicio = novo;
    }
    else{
      aux = lista->inicio;
      while(aux->proximo){
        aux = aux->proximo;
      }
      aux->proximo = novo;
      lista->tam++;
      
    }
  }
}

void imprimir(Lista lista){
  No *no = lista.inicio;
  printf( "Tamanho da lista: %d\n", lista.tam);
  while(no){
    printf("%d ", no->valor);
    no = no->proximo;
    printf("\n\n");
  }
}

int main(){
  int opcao, valor;
  Lista lista, pilha, fila;

  criar_fila(&fila);
  criar_pilha(&pilha);
  criar_lista(&lista);
  
  do{
    printf("0 - Sair\n1 - Inserir no inicio\n2 - Inserir no fim\n3 - Imprimir\n4 - Remover pilha\n");
    scanf("%d", &opcao);
    switch(opcao){
      case 1:
        printf("Digite um valor: ");
        scanf("%d", &valor);
        inserir_pilha(&pilha, valor);
        inserir_fila(&fila, valor);
        inserir_inicio(&lista, valor);
        break;
      case 2:
        printf("Digite um valor: ");
        scanf("%d", &valor);
        inserir_fim(&lista, valor);
        break;
      case 3:
        imprimir_fila(fila);
        break;
      case 4:
        remover_fila(&fila);
        printf("Removida primeiro elemento da fila\n");
        break;
      
      default:
        if(opcao != 0){
          printf("Opção inválida\n");
        }
      
    }
  }
    while(opcao != 0);

  return 0;
}