#include <stdio.h>

int main()
{
  float salario; 
  float somador_s;
  float somador_f; 
  float filhos; 
  float media_s; 
  float media_f;
  int contador;

    while (1)
    {
        printf("Salário: ");
        scanf("%f", &salario);

        if (salario < 0) {break;}
 printf("Número de filhos: ");
 scanf("%f", &filhos);  

        somador_s += salario;
        somador_f += filhos; 
        contador++;    
    }

    media_s = somador_s / contador;
    media_f = somador_f / contador;

    printf("Média de salarios: %.2f$ \n"
           "Média de filhos: %.1f\n", 
            media_s, media_f);
return 0;
}