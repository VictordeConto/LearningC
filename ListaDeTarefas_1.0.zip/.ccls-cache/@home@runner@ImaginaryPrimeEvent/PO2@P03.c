#include <stdio.h>

int soma(int num1, int num2){return num1 + num2;}

int menos(int num1, int num2){return num1 - num2;}

int divi(int num1, int num2){return num1 / num2;}

int multiplica(int num1, int num2){return num1 * num2;}

int main()
{
    char operacao;
    int operando_um;
    int operando_dois;
    int resultado;

    while(1)
    {
        printf("Digite a operação desejada(+, -, /, *, Digite @ para sair): \n");
        scanf(" %c", &operacao);

        if(operacao == '@'){break;}
        if(operacao == '+'){
          printf("Digite os operandos:\n");
            scanf("%d%d", &operando_um, &operando_dois);
            resultado = soma(operando_um, operando_dois);
            printf("Resultado: %d\n", resultado);
        }
        if(operacao == '-'){
            printf("Digite os operandos:\n");
            scanf("%d%d", &operando_um, &operando_dois);
            resultado = menos(operando_um, operando_dois);
            printf("Resultado: %d\n", resultado);
        }
        if(operacao == '/'){
            printf("Digite os operandos:\n");
            scanf("%d%d", &operando_um, &operando_dois);
            resultado = divi(operando_um, operando_dois);
            printf("Resultado: %d\n", resultado);
        }
        if(operacao == '*'){
            printf("Digite os operandos:\n");
            scanf("%d%d", &operando_um, &operando_dois);
            resultado = multiplica(operando_um, operando_dois);
            printf("Resultado: %d\n", resultado);
        }
    }

    return 0;
}