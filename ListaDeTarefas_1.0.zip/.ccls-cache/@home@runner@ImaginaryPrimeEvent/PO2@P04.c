#include <stdio.h>

int main(){ int resultado = 1;
           int i;
printf("Digite um número: ");
scanf("%d", &i);

    if(i==0 || i==1){
        printf("Para 0 e 1 sempre será 1");
    }
    else{
        for(i; i!=1; i--){
            resultado *= i;
        }
        printf("o Fatorial é : %d\n", resultado);
    }

    return 0;
}