#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct noLista {
    int id;
    char tarefa[20];
    char descriTarefa[20];
    int tempConclusao;
    struct noLista *next;
    struct noLista *prev;
} listaTarefa;

typedef struct sent {
    listaTarefa *head;
    listaTarefa *tail;
} sentinela;

void criarLista(sentinela *s) {
    s->head = NULL;
    s->tail = NULL;
}

void inserirElemento(sentinela *s, int sid, char t[], char dt[], int temp) {
    listaTarefa *novo = malloc(sizeof(listaTarefa));
    if (novo) {
        novo->id = sid;
        strcpy(novo->tarefa, t);
        strcpy(novo->descriTarefa, dt);
        novo->tempConclusao = temp;
        novo->next = NULL;
        if (s->head == NULL) {
            s->head = novo;
            s->tail = novo;
            novo->prev = NULL;
        } else {
            s->tail->next = novo;
            novo->prev = s->tail;
            s->tail = novo;
        }
    }
}

void removeTarefa(sentinela *s, int sid) {
    listaTarefa *aux, *aux2 = s->head;

    if (s->tail == NULL || s->head == NULL) {
        printf("Lista Vazia");
        return;
    }

    if (s->head->id == sid) {
        aux = s->head;
        s->head = s->head->next;
        if (s->head)
            s->head->prev = NULL;
        else
            s->tail = NULL;
        free(aux);
        return;
    }

    if (s->tail->id == sid) {
        aux = s->tail;
        s->tail = s->tail->prev;
        if (s->tail)
            s->tail->next = NULL;
        else
            s->head = NULL;
        free(aux);
        return;
    }

    while (aux2 != NULL) {
        if (aux2->id == sid) {
            aux = aux2;
            aux2->next->prev = aux2->prev;
            aux2->prev->next = aux2->next;
            free(aux);
            return;
        }
        aux2 = aux2->next;
    }
}

void imprimiLT(sentinela s) {
    listaTarefa *aux = s.head;
    while (aux) {
        printf("%d %s %s %d\n", aux->id, aux->tarefa, aux->descriTarefa, aux->tempConclusao);
        aux = aux->next;
    }
}

int main() {
    sentinela Sentinela;
    int opcao;
    int idTarefa;
    char nomeTarefa[20];
    char descTarefa[20];
    int tempTarefa;

    criarLista(&Sentinela);

    do {
        printf("\n0 sair \n1 inserir elemento \n2 remover elemento \n3 imprimir\n");
        scanf("%d", &opcao);
        switch (opcao) {
            case 1:
                printf("Digite o nome da tarefa, seu id, tempo e descrição:\n");
                scanf("%s %d %d %s", nomeTarefa, &idTarefa, &tempTarefa, descTarefa);
                inserirElemento(&Sentinela, idTarefa, nomeTarefa, descTarefa, tempTarefa);
                break;
            case 2:
                printf("Digite o id da tarefa a ser removida:\n");
                scanf("%d", &idTarefa);
                removeTarefa(&Sentinela, idTarefa);
                break;
            case 3:
                imprimiLT(Sentinela);
                break;
            default:
                if (opcao != 0) {
                    printf("Opção Inválida\n");
                }
        }
    } while (opcao != 0);

    return 0;
}
