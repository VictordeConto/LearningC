#include <stdio.h>

int main(){
  int matricula=0;
  int nota=0;
  int alunos=0;
  float mediaal = 0.0;
  float mediat=0.0;

    while (1) {printf("Matrícula: ");
    scanf("%d", &matricula);

      if (matricula == 0){break;} 
        mediaal = 0;

        for (int i=1; i !=6; i++){
            printf("Nota %d: ", i);
            scanf("%d", &nota);

            mediaal += nota;
        }

        mediaal /= 5.0 ;
        printf("Aluno: %d Média: %.1f\n", matricula, mediaal);
        alunos++;
        mediat+= mediaal;

    }

    mediat /= (float)alunos;
    printf("Média geral da turma: %.1f \n", mediat);
  return 0;

}