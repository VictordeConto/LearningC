#include <stdio.h>

int soma(int num)
{int i = 0, somador = 0;

    while(i!=num){ 
        i++;
        somador += i;}
  return somador;}

int main()
{int num1, resultado;

    printf("Número: ");
    scanf("%d", &num1);

    resultado = soma(num1);

    printf("Resultado: %d", resultado);

    return 0;}