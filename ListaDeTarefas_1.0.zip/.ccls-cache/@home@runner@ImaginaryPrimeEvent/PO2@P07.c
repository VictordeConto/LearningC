#include <stdio.h>

int main()
{
  int jogo = 1;
  int i = 1; 
  int golum = 0; 
  int goldois = 0;
  int maior = 0;
  int A = 0;
  int B = 0;
  int C = 0; 
  int D = 0;
  char time1;
  char time2;
  char timeVencedor;
  char vencedor;

    while (1)
    {
        printf("Jogo %d\n", jogo);
        while (i!=2)
        {
            printf("Time: ");
            scanf(" %c", &time1);

            if (time1 != 'A' && time1 != 'B' && time1 != 'C' && time1 != 'D' )
            {
                break;
            }

            printf("Gols: ");
            scanf(" %d", &golum);

            printf("Time: ");
            scanf(" %c", &time2);

            if (time2 != 'A' && time2 != 'B' && time2 != 'C' && time2 != 'D' )
            {
                break;
            }

            printf("Gols: ");
            scanf("%d", &goldois);


            i++;
        }

        i = 1;

        if (time1 != 'A' && time1 != 'B' && time1 != 'C' && time1 != 'D' )
        {
            break;
        }

        if (golum > goldois)
        {
            vencedor = time1;
        }
        else{ if (golum == goldois)
        {
            vencedor = 'E';
        }
        else
        {
            vencedor = time2;
        }        
        }

        if (vencedor == 'A')
        {
            A += 3;
        }
        else{ if (vencedor == 'B')
        {
            B += 3;
        }
        else{ if (vencedor == 'C')
        {
            C += 3;
        }
        else{ if(vencedor == 'D')
        {   
            D += 3;
        }
        else{ if (vencedor == 'E')
        {    
            if (time1 == 'A')
            {
                A++;
            }
            if (time1 == 'B')
            {
                B++;
            }  
            if (time1 == 'C')
            {
                C++;
            }
            if (time1 == 'D')
            {
                D++;
            }

            if (time2 == 'A')
            {
                A++;
            }
            if (time2 == 'B')
            {
                B++;
            } 
            if (time2 == 'C')
            {
                C++;
            }
            if (time2 == 'D')
            {
                D++;
            }
        }
        }
        }
        }
        }
        jogo++;
    }

    maior = A;
    timeVencedor = 'A';
    if (B > maior) 
    {
        maior = B;
        timeVencedor = 'B';
    }
    if (C > maior) 
    {
        maior = C;
        timeVencedor = 'C';
    }
    if (D > maior) 
    {
        maior = D;
        timeVencedor = 'D';
    }
    if ((maior == A && timeVencedor != 'A') || (maior == B && timeVencedor != 'B') || (maior == C && timeVencedor != 'C') || (maior == D && timeVencedor != 'D'))
        {
           printf("Não houve campeão\n"); 
        }
        else
        {
            printf("Campeão: %c\n", timeVencedor);
        }


    printf("A: %d\n", A);
    printf("B: %d\n", B);
    printf("C: %d\n", C);
    printf("D: %d\n", D);
}