#include <stdio.h>

int Multiplicacao(int numero, int quantidade)
{
    int i, n_multiplicado = 0;
    for(i=0; i!=quantidade; i++)
    {
        n_multiplicado += numero;
    }
    return n_multiplicado;
}

int main()
{
    int resultado, numero_um , numero_dois;
    printf("Digite dois números para serem multiplicados\n");
    scanf("%d%d", &numero_um, &numero_dois);
    resultado = Multiplicacao(numero_um, numero_dois);

    printf("%d\n", resultado); return 0;
}
