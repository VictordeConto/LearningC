#include <stdio.h>

int main() 
{
  int preço;
  printf("Valor do Produto: ");
  scanf("%d", &preço);

  int formapag;
  printf("Escolha uma forma de pagamento:\n á vista (1)\n á prazo (2)\n");
  scanf("%d", &formapag);


  return 0;
}