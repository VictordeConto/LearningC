#include <stdio.h>

int multiplica(int num1, int num2)
{
  int i;
  int num3 = 0;
    for(i=0; i!=num2; i++)
    {
        num3 += num1;
    }
    return num3;
}

int main()
{
  int resultado;
  int numero_um; 
  int numero_dois;

  
    printf("Digite dois números\n");
    scanf("%d%d", &numero_um, &numero_dois);
    resultado = multiplica(numero_um, numero_dois);

    printf("o primeiro número vezes o segundo número é igual a: %d", resultado);
  return 0;
}