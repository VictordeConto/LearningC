/*#include <stdio.h>
#include <math.h>

unsigned long long int fatorial(int n) {
    if (n == 0 || n == 1)
        return 1;
    else
        return n * fatorial(n - 1);}

double calcularElevado(double z, double y){
  double resultado;
  resultado = pow(z,y);
  return resultado;
}

int main() {
    int n, x;
    double p;
    printf("/// Calculo de distribuição binomial  ///\n");
    printf("Digite o valor de N (inteiro): ");
    scanf("%d", &n);
    printf("Digite o valor de P: ");
    scanf("%lf", &p);
    printf("Digite o valor de X (inteiro): ");
    scanf("%d", &x);
    if (n < 0 || p < 0 || x < 0){
    printf("Digite valores positivos, não trabalhamos com probabilidades negativas!");
      return 0;
   
    }
    if (p > 1){
      p = p / 100;
    }

    unsigned long long int coeficiente_binomial = fatorial(n) / (fatorial(n - x) * fatorial(x));
    float calculoProbabilidade;
    calculoProbabilidade = coeficiente_binomial * calcularElevado(p, x) * calcularElevado(1 - p, n - x);
    double probabilidade_acumulada = 0.0;
    for (int i = 0; i <= x; ++i) {
        unsigned long long int coeficiente_binomial = fatorial(n) / (fatorial(n - i) * fatorial(i));
        double probabilidade = coeficiente_binomial * calcularElevado(p, i) * calcularElevado(1 - p, n - i);
        probabilidade_acumulada += probabilidade;
    }
    
    printf("A probabilidade de x ser igual a %d é: %.2f%\n", x, (calculoProbabilidade * 100));
    printf("A probabilidade de x ser menor ou igual a %d é: %.2f%\n", x, (probabilidade_acumulada * 100));
   

    return 0;
} 
*/
#include <stdio.h>
#include <math.h>

double fatorial(double n) {
    return tgamma(n + 1);
}

double calcularElevado(double z, double y){
    return pow(z, y);
}

int main() {
    double n, x;
    double p;
    printf("Digite o valor de n: ");
    scanf("%lf", &n);
    printf("Digite o valor de p: ");
    scanf("%lf", &p);
    printf("Digite o valor de x: ");
    scanf("%lf", &x);

    unsigned long long int coeficiente_binomial = fatorial(n) / (fatorial(n - x) * fatorial(x));
    double calculoProbabilidade;
    calculoProbabilidade = coeficiente_binomial * calcularElevado(p, x) * calcularElevado(1 - p, n - x);
    double probabilidade_acumulada = 0.0;
    for (int i = 0; i <= x; ++i) {
        unsigned long long int coeficiente_binomial = fatorial(n) / (fatorial(n - i) * fatorial(i));
        double probabilidade = coeficiente_binomial * calcularElevado(p, i) * calcularElevado(1 - p, n - i);
        probabilidade_acumulada += probabilidade;
    }

    printf("A probabilidade de x ser igual a %.2f é: %.2f%%\n", x, (calculoProbabilidade * 100));
    printf("A probabilidade de x ser menor ou igual a %.2f é: %.2f%%\n", x, (probabilidade_acumulada * 100));

    return 0;
}


