#include <stdio.h>

int main(){
  int sequencial;
  int result;
  int i;
  int m20 = 0;
  int num = 0;
 
  

  printf("Digite a quantidade: ");
  scanf("%d", &sequencial);

  for(i=0; i!=sequencial; i++){
        printf("Número: ");
        scanf("%d", &num);

        if(num>10 || num <= 20){
            m20++;
        }  
    } result = ((float)m20/(float)sequencial)* 100;
  printf("A porcentagem entre 10 e 20: %d%% \n", result);
}